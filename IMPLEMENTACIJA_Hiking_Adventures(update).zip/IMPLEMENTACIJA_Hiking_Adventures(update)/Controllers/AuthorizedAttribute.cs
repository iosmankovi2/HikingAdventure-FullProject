﻿using System;

namespace Hiking_Adventures.Controllers
{
    internal class AuthorizedAttribute : Attribute
    {
    }
}